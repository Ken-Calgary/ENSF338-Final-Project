from setuptools import setup
from setuptools import find_packages

setup(name='ENSF 338 Final Project Package',
    version= '1.0',
    description='different types of datastructures',
    author='Zachariah Blair',
    author_email='zachariah.blair@gmail.com',
    packages=find_packages(),
    install_requires=[],
    )